class NodoCola {
    String tarea;
    int prioridad;
    NodoCola siguiente;
    NodoCola anterior;

    public NodoCola(String tarea, int prioridad) {
        this.tarea = tarea;
        this.prioridad = prioridad;
        this.siguiente = null;
        this.anterior = null;
    }
}
