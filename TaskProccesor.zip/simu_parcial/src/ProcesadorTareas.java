public class ProcesadorTareas {
    private PilaDinamica pilaTareasEnProgreso;
    private ColaPriDinamica colaTareasPendientes;

    public ProcesadorTareas() {
        pilaTareasEnProgreso = new PilaDinamica();
        colaTareasPendientes = new ColaPriDinamica();
        pilaTareasEnProgreso.InicializarPila();
    }

    public void agregarTarea(String tarea, int prioridad) {
        colaTareasPendientes.insertar(tarea, prioridad);
    }

    public void comenzarTarea() {
        if (!colaTareasPendientes.estaVacia()) {
            String tarea = colaTareasPendientes.eliminar();
            pilaTareasEnProgreso.Add(tarea);
        } else {
            System.out.println("No hay tareas pendientes para comenzar.");
        }
    }

    public void completarTarea() {
        if (!pilaTareasEnProgreso.IsEmpty()) {
            pilaTareasEnProgreso.Remove();
        } else {
            System.out.println("No hay tareas en progreso para completar.");
        }
    }

    public void listarTareasEnProgreso() {
        System.out.print("Tareas en progreso: ");
        pilaTareasEnProgreso.imprimirPila();
    }

    public void listarTareasPendientes() {
        System.out.print("Tareas pendientes: ");
        colaTareasPendientes.imprimirCola();
    }
}
