public interface PilaInterfaz {
    void InicializarPila();
    void Add(String a);
    void Remove();
    boolean IsEmpty();
    String GetTop();
    }

