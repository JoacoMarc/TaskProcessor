public class ColaPriDinamica {
    private NodoCola primero;
    private NodoCola ultimo;

    public ColaPriDinamica() {
        this.primero = null;
        this.ultimo = null;
    }

    public void insertar(String tarea, int prioridad) {
        NodoCola nuevoNodo = new NodoCola(tarea, prioridad);

        if (primero == null) {  // La cola está vacía
            primero = ultimo = nuevoNodo;
        } else if (primero.prioridad < prioridad) {  // Insertar al principio
            nuevoNodo.siguiente = primero;
            primero.anterior = nuevoNodo;
            primero = nuevoNodo;
        } else {
            NodoCola actual = primero;
            while (actual.siguiente != null && actual.siguiente.prioridad >= prioridad) {
                actual = actual.siguiente;
            }
            nuevoNodo.siguiente = actual.siguiente;
            if (actual.siguiente != null) {
                actual.siguiente.anterior = nuevoNodo;
            } else {
                ultimo = nuevoNodo;
            }
            actual.siguiente = nuevoNodo;
            nuevoNodo.anterior = actual;
        }
    }


    public String eliminar() {
        if (primero == null) {
            throw new IllegalStateException("La cola está vacía");
        }
        String tarea = primero.tarea;
        primero = primero.siguiente;
        if (primero != null) {
            primero.anterior = null;
        } else {
            ultimo = null;
        }
        return tarea;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public String traerPrimero() {
        if (primero == null) {
            throw new IllegalStateException("La cola está vacía");
        }
        return primero.tarea;
    }

    public void imprimirCola() {
        NodoCola actual = primero;
        while (actual != null) {
            System.out.print("(" + actual.tarea + ", " + actual.prioridad + ") ");
            actual = actual.siguiente;
        }
        System.out.println();
    }
}

