class NodoPila {
    String tarea;  // La tarea almacenada en el nodo
    NodoPila siguiente;  // La referencia al siguiente nodo en la lista
}
public class PilaDinamica {
    NodoPila primero; // Referencia al primer elemento (el más reciente) en la pila

    public void InicializarPila() {
        primero = null;
    }

    public void Add(String tarea) {
        NodoPila nuevo = new NodoPila();
        nuevo.tarea = tarea;  // Asignamos la tarea a info
        nuevo.siguiente = primero;  // El siguiente nodo es el antiguo primero

        primero = nuevo;  // Ahora el nuevo nodo es el primero
    }

    public boolean IsEmpty() {
        return primero == null;
    }

    public void Remove() {
        if (!IsEmpty()) {  // Solo desapilamos si hay elementos
            primero = primero.siguiente;  // El primer nodo ahora será el siguiente en la pila
        }
    }

    public String GetTop() {
        if (primero != null) {
            return primero.tarea;  // Retornamos la tarea del primer nodo
        } else {
            throw new IllegalStateException("La pila está vacía."); // Lanzar una excepción si la pila está vacía
        }
    }

    public void imprimirPila() {
        NodoPila actual = primero;
        while (actual != null) {
            System.out.print(actual.tarea + " ");
            actual = actual.siguiente;
        }
        System.out.println(); // Imprimir una línea en blanco al final
    }
}


