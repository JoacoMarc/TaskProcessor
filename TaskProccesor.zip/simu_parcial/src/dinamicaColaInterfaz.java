public interface dinamicaColaInterfaz {
    void insertar(int valor, int prioridad);
    String eliminar();
    boolean estaVacia();
    int traerPrimero();
}
