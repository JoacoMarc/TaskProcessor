import java.util.Random;
public class Main {
    public static void main(String[] args) {
        ProcesadorTareas procesador = new ProcesadorTareas();

        procesador.agregarTarea("Tarea 1", 1);
        procesador.agregarTarea("Tarea 2", 7);
        procesador.agregarTarea("Tarea 3", 44);

        System.out.println("Listar tareas pendientes después de agregar:");
        procesador.listarTareasPendientes();

        procesador.comenzarTarea();
        procesador.comenzarTarea();

        System.out.println("Listar tareas en progreso después de comenzar tareas:");
        procesador.listarTareasEnProgreso();

        System.out.println("Listar tareas pendientes después de comenzar tareas:");
        procesador.listarTareasPendientes();

        procesador.completarTarea();

        System.out.println("Listar tareas en progreso después de completar una tarea:");
        procesador.listarTareasEnProgreso();
    }
}